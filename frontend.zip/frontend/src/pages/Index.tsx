import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, ArrowRight, Zap, BarChart3, Lock } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is already logged in
    const token = localStorage.getItem("authToken");
    if (token) {
      navigate("/dashboard");
    }
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-hero opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="mx-auto w-20 h-20 rounded-2xl gradient-hero flex items-center justify-center mb-8 shadow-glow">
              <Shield className="h-10 w-10 text-white" />
            </div>
            
            <h1 className="text-5xl lg:text-6xl font-bold mb-6">
              <span className="text-gradient">FraudShield</span>
            </h1>
            
            <p className="text-xl lg:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Advanced AI-powered fraud detection system that protects your business 
              from financial crimes with real-time analysis and machine learning
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                variant="hero" 
                size="lg" 
                onClick={() => navigate("/login")}
                className="flex items-center space-x-2"
              >
                <span>Get Started</span>
                <ArrowRight className="h-5 w-5" />
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => navigate("/login")}
              >
                View Demo
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-muted/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Why Choose FraudShield?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our cutting-edge platform combines artificial intelligence with real-time monitoring 
              to provide unparalleled fraud protection for your business.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="card-enhanced border-0 text-center">
              <CardContent className="p-8">
                <div className="w-16 h-16 mx-auto mb-6 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Zap className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Real-time Detection</h3>
                <p className="text-muted-foreground">
                  Analyze transactions in milliseconds with our advanced AI algorithms 
                  for instant fraud detection and prevention.
                </p>
              </CardContent>
            </Card>

            <Card className="card-enhanced border-0 text-center">
              <CardContent className="p-8">
                <div className="w-16 h-16 mx-auto mb-6 rounded-xl bg-success/10 flex items-center justify-center">
                  <BarChart3 className="h-8 w-8 text-success" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Advanced Analytics</h3>
                <p className="text-muted-foreground">
                  Get comprehensive insights with detailed reports, trend analysis, 
                  and predictive modeling to stay ahead of fraudsters.
                </p>
              </CardContent>
            </Card>

            <Card className="card-enhanced border-0 text-center">
              <CardContent className="p-8">
                <div className="w-16 h-16 mx-auto mb-6 rounded-xl bg-purple/10 flex items-center justify-center">
                  <Lock className="h-8 w-8 text-purple" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Enterprise Security</h3>
                <p className="text-muted-foreground">
                  Bank-level security with encrypted data transmission, secure APIs, 
                  and compliance with industry standards.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-primary mb-2">99.8%</div>
              <div className="text-muted-foreground">Detection Accuracy</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">&lt;50ms</div>
              <div className="text-muted-foreground">Response Time</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">$2.5M+</div>
              <div className="text-muted-foreground">Fraud Prevented</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">24/7</div>
              <div className="text-muted-foreground">Monitoring</div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 bg-muted/20">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-6">
            Ready to Protect Your Business?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Join thousands of businesses that trust FraudShield to protect their transactions 
            and prevent financial fraud.
          </p>
          <Button 
            variant="hero" 
            size="lg"
            onClick={() => navigate("/login")}
            className="flex items-center space-x-2 mx-auto"
          >
            <span>Start Free Trial</span>
            <ArrowRight className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-border py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="p-2 rounded-lg gradient-hero">
              <Shield className="h-5 w-5 text-white" />
            </div>
            <span className="text-lg font-semibold">FraudShield</span>
          </div>
          <p className="text-muted-foreground">
            © 2024 FraudShield. All rights reserved. | Advanced AI Fraud Detection Platform
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;