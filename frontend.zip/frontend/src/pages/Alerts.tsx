import { useState, useEffect } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  AlertTriangle, 
  Download, 
  Clock,
  DollarSign,
  TrendingUp
} from "lucide-react";
import { getAlerts } from "@/services/mockApi";
import { useToast } from "@/hooks/use-toast";
import type { Alert } from "@/services/mockApi";

export default function Alerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadAlerts();
  }, []);

  const loadAlerts = async () => {
    try {
      const data = await getAlerts();
      setAlerts(data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    } catch (error) {
      toast({
        title: "Error loading alerts",
        description: "Failed to fetch alert data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const downloadJson = () => {
    const jsonContent = JSON.stringify(alerts, null, 2);
    const blob = new Blob([jsonContent], { type: "application/json" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "fraud-alerts.json";
    a.click();
    window.URL.revokeObjectURL(url);

    toast({
      title: "JSON Downloaded",
      description: `Downloaded ${alerts.length} alerts`,
    });
  };

  const getPriorityColor = (probability: number) => {
    if (probability >= 90) return "border-red-500 bg-red-50";
    if (probability >= 80) return "border-orange-500 bg-orange-50";
    if (probability >= 70) return "border-yellow-500 bg-yellow-50";
    return "border-gray-300 bg-gray-50";
  };

  const getPriorityBadge = (probability: number) => {
    if (probability >= 90) return <Badge variant="destructive">Critical</Badge>;
    if (probability >= 80) return <Badge variant="secondary" className="bg-orange-100 text-orange-800">High</Badge>;
    if (probability >= 70) return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">Medium</Badge>;
    return <Badge variant="secondary">Low</Badge>;
  };

  const formatTimeAgo = (date: string) => {
    const now = new Date();
    const alertDate = new Date(date);
    const diffInMinutes = Math.floor((now.getTime() - alertDate.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  if (loading) {
    return (
      <div className="flex h-screen">
        <Sidebar />
        <div className="flex-1 md:ml-64 p-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="space-y-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-32 bg-muted rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const criticalAlerts = alerts.filter(a => a.probability >= 90);
  const highAlerts = alerts.filter(a => a.probability >= 80 && a.probability < 90);
  const totalAmount = alerts.reduce((sum, alert) => sum + alert.amount, 0);

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 md:ml-64 overflow-auto">
        <main className="p-6 lg:p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Fraud Alerts</h1>
            <p className="text-muted-foreground">Monitor and manage suspicious transaction alerts</p>
          </div>

          {/* Alert Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="card-enhanced border-0">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">Critical Alerts</p>
                    <p className="text-2xl font-bold text-red-600">{criticalAlerts.length}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-red-100">
                    <AlertTriangle className="h-6 w-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-enhanced border-0">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">High Priority</p>
                    <p className="text-2xl font-bold text-orange-600">{highAlerts.length}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-orange-100">
                    <TrendingUp className="h-6 w-6 text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="card-enhanced border-0">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">Total Amount at Risk</p>
                    <p className="text-2xl font-bold text-foreground">${totalAmount.toLocaleString()}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-primary/10">
                    <DollarSign className="h-6 w-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Alerts List */}
          <Card className="card-enhanced border-0">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5" />
                <span>Recent Alerts ({alerts.length})</span>
              </CardTitle>
              <Button 
                variant="outline" 
                onClick={downloadJson}
                className="flex items-center space-x-2"
              >
                <Download className="h-4 w-4" />
                <span>Export JSON</span>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {alerts.map((alert) => (
                  <Card 
                    key={alert.id} 
                    className={`border-l-4 transition-all duration-200 hover:shadow-md ${getPriorityColor(alert.probability)}`}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-3">
                            <div className="p-2 rounded-lg bg-red-100">
                              <AlertTriangle className="h-4 w-4 text-red-600" />
                            </div>
                            <div>
                              <h3 className="font-semibold text-foreground">
                                Suspicious Transaction Detected
                              </h3>
                              <p className="text-sm text-muted-foreground">
                                Transaction ID: {alert.transactionId}
                              </p>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                            <div>
                              <p className="text-xs text-muted-foreground">Amount</p>
                              <p className="font-semibold text-foreground">
                                ${alert.amount.toLocaleString()}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Fraud Probability</p>
                              <p className="font-semibold text-foreground">
                                {alert.probability}%
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Time</p>
                              <p className="font-semibold text-foreground flex items-center">
                                <Clock className="h-3 w-3 mr-1" />
                                {formatTimeAgo(alert.date)}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Priority</p>
                              <div className="mt-1">
                                {getPriorityBadge(alert.probability)}
                              </div>
                            </div>
                          </div>
                          
                          <div className="p-3 bg-muted/50 rounded-lg">
                            <p className="text-sm text-muted-foreground mb-1">
                              <strong>Reason:</strong>
                            </p>
                            <p className="text-sm text-foreground">{alert.reason}</p>
                          </div>
                        </div>
                        
                        <div className="ml-4 flex flex-col space-y-2">
                          <Button variant="outline" size="sm">
                            Investigate
                          </Button>
                          <Button variant="ghost" size="sm">
                            Mark Safe
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              {alerts.length === 0 && (
                <div className="text-center py-12">
                  <AlertTriangle className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No alerts found</h3>
                  <p className="text-muted-foreground">
                    All transactions appear to be safe at the moment.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}