import { useState, useEffect } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Key, 
  Copy, 
  Eye, 
  EyeOff, 
  Code, 
  Zap,
  Activity
} from "lucide-react";
import { generateApiKey, getTransactions } from "@/services/mockApi";
import { useToast } from "@/hooks/use-toast";
import type { Transaction } from "@/services/mockApi";

export default function ApiIntegration() {
  const [apiKey, setApiKey] = useState("fs_xxxxxxxxxxxxxxxxxxxxxxxxxxxx");
  const [showApiKey, setShowApiKey] = useState(false);
  const [liveTransactions, setLiveTransactions] = useState<Transaction[]>([]);
  const [generating, setGenerating] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Load initial transactions
    loadTransactions();

    // Simulate live updates every 5 seconds
    const interval = setInterval(() => {
      loadTransactions();
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const loadTransactions = async () => {
    try {
      const transactions = await getTransactions();
      // Show only the latest 10 transactions
      setLiveTransactions(transactions.slice(0, 10));
    } catch (error) {
      console.error("Failed to load transactions:", error);
    }
  };

  const handleGenerateApiKey = async () => {
    setGenerating(true);
    try {
      const newApiKey = await generateApiKey();
      setApiKey(newApiKey);
      toast({
        title: "API Key Generated",
        description: "Your new API key has been generated successfully",
      });
    } catch (error) {
      toast({
        title: "Generation failed",
        description: "Failed to generate API key",
        variant: "destructive",
      });
    } finally {
      setGenerating(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(apiKey);
    toast({
      title: "Copied!",
      description: "API key copied to clipboard",
    });
  };

  const getFraudBadge = (probability: number) => {
    if (probability >= 80) return <Badge variant="destructive">High Risk</Badge>;
    if (probability >= 50) return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">Medium Risk</Badge>;
    return <Badge variant="secondary" className="bg-green-100 text-green-800">Low Risk</Badge>;
  };

  const curlExample = `curl -X POST https://api.fraudshield.com/v1/analyze \\
  -H "Authorization: Bearer ${apiKey}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "transaction_id": "txn_123456",
    "amount": 1500.00,
    "merchant": "Online Store",
    "timestamp": "2024-01-15T10:30:00Z",
    "user_id": "user_789",
    "payment_method": "credit_card"
  }'`;

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 md:ml-64 overflow-auto">
        <main className="p-6 lg:p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">API Integration</h1>
            <p className="text-muted-foreground">Integrate real-time fraud detection into your systems</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* API Key Management */}
            <Card className="card-enhanced border-0">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Key className="h-5 w-5" />
                  <span>API Key</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Your API Key</label>
                  <div className="flex space-x-2">
                    <div className="relative flex-1">
                      <Input
                        type={showApiKey ? "text" : "password"}
                        value={apiKey}
                        readOnly
                        className="pr-10 font-mono"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full"
                        onClick={() => setShowApiKey(!showApiKey)}
                      >
                        {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                    <Button variant="outline" size="icon" onClick={copyToClipboard}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <Button 
                  variant="primary" 
                  onClick={handleGenerateApiKey}
                  disabled={generating}
                  className="w-full"
                >
                  {generating ? "Generating..." : "Generate New Key"}
                </Button>
                
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="text-xs text-muted-foreground">
                    Keep your API key secure. Don't share it in client-side code or public repositories.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* API Usage Stats */}
            <Card className="card-enhanced border-0">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5" />
                  <span>Usage Statistics</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-primary/5 rounded-lg">
                    <div className="text-2xl font-bold text-primary">1,247</div>
                    <div className="text-xs text-muted-foreground">API Calls Today</div>
                  </div>
                  <div className="text-center p-4 bg-success/5 rounded-lg">
                    <div className="text-2xl font-bold text-success">99.9%</div>
                    <div className="text-xs text-muted-foreground">Uptime</div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Monthly Quota</span>
                    <span>8,456 / 10,000</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-primary h-2 rounded-full" style={{ width: "84.56%" }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Code Example */}
          <Card className="card-enhanced border-0 mb-8">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Code className="h-5 w-5" />
                <span>Example Usage</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-slate-900 text-slate-100 p-4 rounded-lg overflow-x-auto">
                <pre className="text-sm">
                  <code>{curlExample}</code>
                </pre>
              </div>
              <div className="mt-4 p-4 bg-muted/50 rounded-lg">
                <h4 className="font-semibold mb-2">Response:</h4>
                <pre className="text-xs text-muted-foreground">
{`{
  "transaction_id": "txn_123456",
  "fraud_probability": 0.15,
  "risk_level": "low",
  "factors": [
    "normal_spending_pattern",
    "verified_merchant"
  ]
}`}
                </pre>
              </div>
            </CardContent>
          </Card>

          {/* Live Transaction Feed */}
          <Card className="card-enhanced border-0">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <Zap className="h-5 w-5" />
                <span>Live Transaction Feed</span>
              </CardTitle>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-muted-foreground">Live</span>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Transaction ID</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Merchant</TableHead>
                      <TableHead>Time</TableHead>
                      <TableHead>Fraud Probability</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {liveTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell className="font-mono text-sm">
                          {transaction.id}
                        </TableCell>
                        <TableCell className="font-semibold">
                          ${transaction.amount.toLocaleString()}
                        </TableCell>
                        <TableCell>{transaction.merchant}</TableCell>
                        <TableCell className="text-sm">
                          {new Date(transaction.date).toLocaleTimeString()}
                        </TableCell>
                        <TableCell className="font-mono">
                          {transaction.fraudProbability}%
                        </TableCell>
                        <TableCell>
                          {getFraudBadge(transaction.fraudProbability)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}