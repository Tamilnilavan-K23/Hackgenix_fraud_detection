import { useState, useEffect } from "react";
import { Sidebar } from "@/components/Sidebar";
import { StatCard } from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  BarChart3, 
  Download, 
  TrendingUp,
  TrendingDown,
  Shield,
  AlertTriangle,
  DollarSign,
  Activity
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from "recharts";
import { getDashboardStats, getFraudTrendData } from "@/services/mockApi";
import { useToast } from "@/hooks/use-toast";
import type { DashboardStats } from "@/services/mockApi";

export default function Reports() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const data = await getDashboardStats();
      setStats(data);
    } catch (error) {
      toast({
        title: "Error loading data",
        description: "Failed to fetch report data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const downloadReport = () => {
    const reportData = {
      generated_at: new Date().toISOString(),
      summary: stats,
      fraud_trend: getFraudTrendData(),
      report_period: "Last 30 days"
    };

    const jsonContent = JSON.stringify(reportData, null, 2);
    const blob = new Blob([jsonContent], { type: "application/json" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `fraud-report-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    window.URL.revokeObjectURL(url);

    toast({
      title: "Report Downloaded",
      description: "Fraud detection report has been downloaded",
    });
  };

  const fraudTrendData = getFraudTrendData();
  
  const monthlyStats = [
    { month: "Jan", prevented: 45000, detected: 67 },
    { month: "Feb", prevented: 52000, detected: 78 },
    { month: "Mar", prevented: 38000, detected: 56 },
    { month: "Apr", prevented: 61000, detected: 89 },
    { month: "May", prevented: 72000, detected: 103 },
    { month: "Jun", prevented: 58000, detected: 82 }
  ];

  if (loading) {
    return (
      <div className="flex h-screen">
        <Sidebar />
        <div className="flex-1 md:ml-64 p-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-32 bg-muted rounded-xl"></div>
              ))}
            </div>
            <div className="h-96 bg-muted rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 md:ml-64 overflow-auto">
        <main className="p-6 lg:p-8">
          <div className="flex justify-between items-start mb-8">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Reports</h1>
              <p className="text-muted-foreground">Comprehensive fraud detection analytics and insights</p>
            </div>
            <Button 
              variant="hero"
              onClick={downloadReport}
              className="flex items-center space-x-2"
            >
              <Download className="h-4 w-4" />
              <span>Download Report</span>
            </Button>
          </div>

          {/* Summary Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard
              title="Total Fraud Prevented"
              value={`$${(stats?.suspiciousAmount || 0).toLocaleString()}`}
              subtitle="Amount saved"
              icon={<Shield className="h-6 w-6" />}
              trend={{ value: 23, isPositive: true }}
            />
            <StatCard
              title="Detection Accuracy"
              value="94.2%"
              subtitle="AI model performance"
              icon={<TrendingUp className="h-6 w-6" />}
              trend={{ value: 2.1, isPositive: true }}
            />
            <StatCard
              title="Response Time"
              value="127ms"
              subtitle="Average detection time"
              icon={<Activity className="h-6 w-6" />}
              trend={{ value: 8.5, isPositive: false }}
            />
            <StatCard
              title="Alerts Generated"
              value={stats?.suspiciousTransactions || 0}
              subtitle="This month"
              icon={<AlertTriangle className="h-6 w-6" />}
              trend={{ value: 15, isPositive: false }}
            />
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Fraud Trend Chart */}
            <Card className="card-enhanced border-0">
              <CardHeader>
                <CardTitle>Fraud Detection Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={fraudTrendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis 
                        dataKey="month" 
                        stroke="hsl(var(--muted-foreground))"
                        fontSize={12}
                      />
                      <YAxis 
                        stroke="hsl(var(--muted-foreground))"
                        fontSize={12}
                      />
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px"
                        }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="fraudCount" 
                        stroke="hsl(var(--danger))" 
                        strokeWidth={3}
                        dot={{ fill: "hsl(var(--danger))", strokeWidth: 2, r: 4 }}
                        name="Fraud Detected"
                      />
                      <Line 
                        type="monotone" 
                        dataKey="totalCount" 
                        stroke="hsl(var(--primary))" 
                        strokeWidth={2}
                        dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 3 }}
                        name="Total Transactions"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Prevention Impact Chart */}
            <Card className="card-enhanced border-0">
              <CardHeader>
                <CardTitle>Fraud Prevention Impact</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyStats}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis 
                        dataKey="month" 
                        stroke="hsl(var(--muted-foreground))"
                        fontSize={12}
                      />
                      <YAxis 
                        stroke="hsl(var(--muted-foreground))"
                        fontSize={12}
                      />
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px"
                        }}
                        formatter={(value, name) => [
                          name === "prevented" ? `$${value.toLocaleString()}` : value,
                          name === "prevented" ? "Amount Prevented" : "Fraud Cases"
                        ]}
                      />
                      <Bar 
                        dataKey="prevented" 
                        fill="hsl(var(--success))" 
                        radius={[4, 4, 0, 0]}
                        name="prevented"
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Key Performance Indicators */}
            <Card className="card-enhanced border-0">
              <CardHeader>
                <CardTitle>Key Performance Indicators</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">False Positive Rate</p>
                    <p className="text-2xl font-bold text-foreground">2.3%</p>
                  </div>
                  <div className="text-right">
                    <TrendingDown className="h-4 w-4 text-success inline" />
                    <span className="text-xs text-success ml-1">-0.5%</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">True Positive Rate</p>
                    <p className="text-2xl font-bold text-foreground">97.8%</p>
                  </div>
                  <div className="text-right">
                    <TrendingUp className="h-4 w-4 text-success inline" />
                    <span className="text-xs text-success ml-1">+1.2%</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Processing Speed</p>
                    <p className="text-2xl font-bold text-foreground">127ms</p>
                  </div>
                  <div className="text-right">
                    <TrendingDown className="h-4 w-4 text-success inline" />
                    <span className="text-xs text-success ml-1">-15ms</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Risk Categories */}
            <Card className="card-enhanced border-0">
              <CardHeader>
                <CardTitle>Risk Categories</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">High Risk (≥80%)</span>
                    <span className="text-sm font-semibold text-red-600">23 cases</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-red-500 h-2 rounded-full" style={{ width: "15%" }}></div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Medium Risk (50-79%)</span>
                    <span className="text-sm font-semibold text-yellow-600">45 cases</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-yellow-500 h-2 rounded-full" style={{ width: "30%" }}></div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Low Risk (&lt;50%)</span>
                    <span className="text-sm font-semibold text-green-600">132 cases</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: "55%" }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* System Health */}
            <Card className="card-enhanced border-0">
              <CardHeader>
                <CardTitle>System Health</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  <div className="w-20 h-20 mx-auto mb-4 relative">
                    <div className="w-20 h-20 rounded-full border-8 border-green-200"></div>
                    <div className="w-20 h-20 rounded-full border-8 border-green-500 border-t-transparent absolute top-0 left-0 transform rotate-45"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-2xl font-bold text-green-600">99%</span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">System Uptime</p>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">API Response Time</span>
                    <span className="text-sm font-semibold text-green-600">Excellent</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Model Accuracy</span>
                    <span className="text-sm font-semibold text-green-600">High</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Data Quality</span>
                    <span className="text-sm font-semibold text-green-600">Optimal</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}