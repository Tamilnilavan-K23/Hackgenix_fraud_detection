import { useEffect, useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { StatCard } from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  CreditCard, 
  AlertTriangle, 
  DollarSign, 
  TrendingUp,
  Upload,
  Key
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { getDashboardStats, getFraudTrendData, getFraudDistributionData } from "@/services/mockApi";
import type { DashboardStats } from "@/services/mockApi";

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      try {
        const data = await getDashboardStats();
        setStats(data);
      } catch (error) {
        console.error("Failed to load dashboard stats:", error);
      } finally {
        setLoading(false);
      }
    };

    loadStats();
  }, []);

  const fraudTrendData = getFraudTrendData();
  const fraudDistributionData = getFraudDistributionData();

  if (loading) {
    return (
      <div className="flex h-screen">
        <Sidebar />
        <div className="flex-1 md:ml-64 p-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-32 bg-muted rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 md:ml-64 overflow-auto">
        <main className="p-6 lg:p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
            <p className="text-muted-foreground">Monitor fraud detection metrics and system performance</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard
              title="Total Transactions"
              value={stats?.totalTransactions.toLocaleString() || "0"}
              subtitle="Last 30 days"
              icon={<CreditCard className="h-6 w-6" />}
              trend={{ value: 12, isPositive: true }}
            />
            <StatCard
              title="Suspicious Transactions"
              value={stats?.suspiciousTransactions || "0"}
              subtitle="Flagged for review"
              icon={<AlertTriangle className="h-6 w-6" />}
              trend={{ value: 8, isPositive: false }}
            />
            <StatCard
              title="Suspicious Amount"
              value={`$${stats?.suspiciousAmount.toLocaleString() || "0"}`}
              subtitle="Total flagged value"
              icon={<DollarSign className="h-6 w-6" />}
              trend={{ value: 15, isPositive: false }}
            />
            <StatCard
              title="Fraud Detection Rate"
              value={`${stats?.fraudPercentage || 0}%`}
              subtitle="Detection accuracy"
              icon={<TrendingUp className="h-6 w-6" />}
              trend={{ value: 3, isPositive: true }}
            />
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <Card className="card-enhanced border-0">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Upload className="h-5 w-5" />
                  <span>Quick Upload</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Upload transaction data for immediate fraud analysis
                </p>
                <Button variant="primary" size="lg" className="w-full">
                  Upload File
                </Button>
              </CardContent>
            </Card>

            <Card className="card-enhanced border-0">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Key className="h-5 w-5" />
                  <span>API Integration</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Generate API key for real-time fraud detection
                </p>
                <Button variant="success" size="lg" className="w-full">
                  Generate API Key
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="card-enhanced border-0">
              <CardHeader>
                <CardTitle>Fraud Trend Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={fraudTrendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis 
                        dataKey="month" 
                        stroke="hsl(var(--muted-foreground))"
                        fontSize={12}
                      />
                      <YAxis 
                        stroke="hsl(var(--muted-foreground))"
                        fontSize={12}
                      />
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px"
                        }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="fraudCount" 
                        stroke="hsl(var(--danger))" 
                        strokeWidth={3}
                        dot={{ fill: "hsl(var(--danger))", strokeWidth: 2, r: 4 }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="totalCount" 
                        stroke="hsl(var(--primary))" 
                        strokeWidth={2}
                        dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 3 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="card-enhanced border-0">
              <CardHeader>
                <CardTitle>Fraud Distribution by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={fraudDistributionData}
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        dataKey="count"
                        label={(entry: any) => `${entry.category}: ${entry.count}`}
                      >
                        {fraudDistributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px"
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}