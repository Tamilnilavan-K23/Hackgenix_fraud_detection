import { useState, useCallback } from "react";
import { Sidebar } from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Upload as UploadIcon, FileText, AlertCircle, CheckCircle } from "lucide-react";
import { uploadFile, runFraudDetection } from "@/services/mockApi";
import { useToast } from "@/hooks/use-toast";
import Papa from "papaparse";

export default function Upload() {
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadedData, setUploadedData] = useState<any[]>([]);
  const [processing, setProcessing] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const { toast } = useToast();

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFileUpload(files[0]);
  }, []);

  const handleFileUpload = async (file: File) => {
    if (!file) return;

    if (file.type === "text/csv" || file.name.endsWith('.csv')) {
      Papa.parse(file, {
        header: true,
        complete: (results) => {
          const data = results.data.slice(0, 10); // Show first 10 rows
          setUploadedData(data);
          toast({
            title: "File uploaded successfully",
            description: `Parsed ${data.length} rows from CSV file`,
          });
        },
        error: (error) => {
          toast({
            title: "Error parsing CSV",
            description: error.message,
            variant: "destructive",
          });
        }
      });
    } else {
      try {
        const result = await uploadFile(file);
        if (result.success && result.data) {
          setUploadedData(result.data);
          toast({
            title: "File uploaded successfully",
            description: `Processed ${result.data.length} rows`,
          });
        }
      } catch (error) {
        toast({
          title: "Upload failed",
          description: "Failed to process the file",
          variant: "destructive",
        });
      }
    }
  };

  const handleRunDetection = async () => {
    if (uploadedData.length === 0) return;

    setProcessing(true);
    try {
      const result = await runFraudDetection(uploadedData);
      if (result.success && result.results) {
        setResults(result.results);
        toast({
          title: "Fraud detection completed",
          description: `Analyzed ${result.results.length} transactions`,
        });
      }
    } catch (error) {
      toast({
        title: "Detection failed",
        description: "Failed to run fraud detection",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  const getFraudBadge = (probability: number) => {
    if (probability >= 80) return <span className="fraud-badge-high">High Risk</span>;
    if (probability >= 50) return <span className="fraud-badge-medium">Medium Risk</span>;
    return <span className="fraud-badge-low">Low Risk</span>;
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 md:ml-64 overflow-auto">
        <main className="p-6 lg:p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Data Upload</h1>
            <p className="text-muted-foreground">Upload transaction data for fraud analysis</p>
          </div>

          {/* Upload Area */}
          <Card className="card-enhanced border-0 mb-8">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <UploadIcon className="h-5 w-5" />
                <span>Upload Transaction Data</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div
                className={`border-2 border-dashed rounded-xl p-12 text-center transition-all duration-200 ${
                  isDragOver 
                    ? "border-primary bg-primary/5" 
                    : "border-border hover:border-primary/50"
                }`}
                onDrop={handleDrop}
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragOver(true);
                }}
                onDragLeave={() => setIsDragOver(false)}
              >
                <div className="space-y-4">
                  <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                    <FileText className="h-8 w-8 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-2">
                      Drop your CSV or JSON file here
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      or click to browse your files
                    </p>
                  </div>
                  <input
                    type="file"
                    accept=".csv,.json"
                    onChange={(e) => e.target.files && handleFileUpload(e.target.files[0])}
                    className="hidden"
                    id="file-upload"
                  />
                  <label htmlFor="file-upload">
                    <Button variant="primary" className="cursor-pointer">
                      Choose File
                    </Button>
                  </label>
                  <p className="text-xs text-muted-foreground">
                    Supported formats: CSV, JSON (max 10MB)
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Preview Data */}
          {uploadedData.length > 0 && (
            <Card className="card-enhanced border-0 mb-8">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-success" />
                  <span>Data Preview</span>
                </CardTitle>
                <Button 
                  variant="hero"
                  onClick={handleRunDetection}
                  disabled={processing}
                >
                  {processing ? "Processing..." : "Run Fraud Detection"}
                </Button>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        {Object.keys(uploadedData[0] || {}).map((key) => (
                          <TableHead key={key} className="font-semibold">
                            {key}
                          </TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {uploadedData.map((row, index) => (
                        <TableRow key={index}>
                          {Object.values(row).map((value: any, i) => (
                            <TableCell key={i} className="font-mono text-sm">
                              {String(value)}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Results */}
          {results.length > 0 && (
            <Card className="card-enhanced border-0">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertCircle className="h-5 w-5 text-primary" />
                  <span>Fraud Detection Results</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Transaction ID</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Merchant</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Fraud Probability</TableHead>
                        <TableHead>Risk Level</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {results.map((result) => (
                        <TableRow key={result.id}>
                          <TableCell className="font-mono">{result.id}</TableCell>
                          <TableCell className="font-semibold">
                            ${result.amount.toLocaleString()}
                          </TableCell>
                          <TableCell>{result.merchant}</TableCell>
                          <TableCell>
                            {new Date(result.date).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="font-mono">
                            {result.fraudProbability}%
                          </TableCell>
                          <TableCell>
                            {getFraudBadge(result.fraudProbability)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </div>
  );
}