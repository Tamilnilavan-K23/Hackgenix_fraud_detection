// Mock API service for fraud detection

export interface Transaction {
  id: string;
  amount: number;
  date: string;
  fraudProbability: number;
  status: 'safe' | 'suspicious' | 'fraud';
  merchant?: string;
  location?: string;
  category?: string;
}

export interface DashboardStats {
  totalTransactions: number;
  suspiciousTransactions: number;
  suspiciousAmount: number;
  fraudPercentage: number;
}

export interface Alert {
  id: string;
  transactionId: string;
  amount: number;
  probability: number;
  date: string;
  reason: string;
}

// Mock data
const generateMockTransaction = (): Transaction => {
  const probability = Math.random();
  let status: 'safe' | 'suspicious' | 'fraud' = 'safe';
  
  if (probability > 0.8) status = 'fraud';
  else if (probability > 0.5) status = 'suspicious';
  
  const merchants = ['Amazon', 'Walmart', 'Target', 'Gas Station', 'Restaurant', 'ATM'];
  const locations = ['New York', 'Los Angeles', 'Chicago', 'Miami', 'Seattle', 'Boston'];
  const categories = ['E-commerce', 'Retail', 'Gas', 'Food', 'ATM', 'Online'];
  
  return {
    id: `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    amount: Math.floor(Math.random() * 5000) + 10,
    date: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
    fraudProbability: Math.floor(probability * 100),
    status,
    merchant: merchants[Math.floor(Math.random() * merchants.length)],
    location: locations[Math.floor(Math.random() * locations.length)],
    category: categories[Math.floor(Math.random() * categories.length)]
  };
};

// Generate mock transactions
export const mockTransactions: Transaction[] = Array.from({ length: 100 }, generateMockTransaction);

export const mockStats: DashboardStats = {
  totalTransactions: mockTransactions.length,
  suspiciousTransactions: mockTransactions.filter(t => t.status !== 'safe').length,
  suspiciousAmount: mockTransactions
    .filter(t => t.status !== 'safe')
    .reduce((sum, t) => sum + t.amount, 0),
  fraudPercentage: Math.round((mockTransactions.filter(t => t.status === 'fraud').length / mockTransactions.length) * 100)
};

export const mockAlerts: Alert[] = mockTransactions
  .filter(t => t.fraudProbability > 70)
  .map(t => ({
    id: `ALERT-${t.id}`,
    transactionId: t.id,
    amount: t.amount,
    probability: t.fraudProbability,
    date: t.date,
    reason: t.fraudProbability > 90 ? 'Extremely high amount deviation' : 'Suspicious pattern detected'
  }));

// Mock API functions
export const login = async (email: string, password: string): Promise<{ success: boolean; token?: string }> => {
  await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network delay
  
  if (email === 'admin@fraudshield.com' && password === 'password') {
    return { success: true, token: 'mock-jwt-token' };
  }
  
  return { success: false };
};

export const getTransactions = async (): Promise<Transaction[]> => {
  await new Promise(resolve => setTimeout(resolve, 500));
  return [...mockTransactions];
};

export const getDashboardStats = async (): Promise<DashboardStats> => {
  await new Promise(resolve => setTimeout(resolve, 300));
  return mockStats;
};

export const getAlerts = async (): Promise<Alert[]> => {
  await new Promise(resolve => setTimeout(resolve, 400));
  return [...mockAlerts];
};

export const uploadFile = async (file: File): Promise<{ success: boolean; data?: any[] }> => {
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // Mock CSV parsing result
  const mockData = Array.from({ length: 10 }, (_, i) => ({
    id: `CSV-${i + 1}`,
    amount: Math.floor(Math.random() * 1000) + 50,
    merchant: 'Sample Merchant',
    date: new Date().toISOString().split('T')[0]
  }));
  
  return { success: true, data: mockData };
};

export const runFraudDetection = async (data: any[]): Promise<{ success: boolean; results?: Transaction[] }> => {
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  const results = data.map((item, i) => ({
    ...generateMockTransaction(),
    id: item.id || `PROCESSED-${i}`,
    amount: item.amount || Math.floor(Math.random() * 1000) + 50
  }));
  
  return { success: true, results };
};

export const generateApiKey = async (): Promise<string> => {
  await new Promise(resolve => setTimeout(resolve, 800));
  return 'fs_' + Math.random().toString(36).substr(2, 32);
};

// Chart data generators
export const getFraudTrendData = () => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  return months.map(month => ({
    month,
    fraudCount: Math.floor(Math.random() * 50) + 10,
    totalCount: Math.floor(Math.random() * 200) + 100
  }));
};

export const getFraudDistributionData = () => {
  const categories = ['E-commerce', 'ATM', 'Retail', 'Online', 'Other'];
  return categories.map(category => ({
    category,
    count: Math.floor(Math.random() * 30) + 5,
    fill: `hsl(${Math.random() * 360}, 70%, 50%)`
  }));
};